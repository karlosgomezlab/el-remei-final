'use client';

import { useState, useEffect, use } from 'react';
import { createClient } from '@supabase/supabase-js';
import { ShoppingCart, Plus, Loader2, Search, ArrowLeft, Utensils, CheckCircle, Trash2, Minus, X } from 'lucide-react';
import { Product } from '@/../../shared/types';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';

const CATEGORIES = [
    { id: 'entrante', name: 'Entrantes', icon: '🥗' },
    { id: 'primero', name: 'Primeros', icon: '🍜' },
    { id: 'segundo', name: 'Segundos', icon: '🥩' },
    { id: 'postre', name: 'Postres', icon: '🍰' },
    { id: 'bebida', name: 'Bebidas', icon: '🍷' },
];

export default function MenuCliente({ params }: { params: Promise<{ id: string }> }) {
    const { id: tableId } = use(params);

    // Inicializar Supabase
    const supabase = createClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    );
    const [menu, setMenu] = useState<Product[]>([]);
    const [cart, setCart] = useState<{ product: Product; qty: number }[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeCategory, setActiveCategory] = useState('primero');
    const [totalOrders, setTotalOrders] = useState(0);
    const [activeOrders, setActiveOrders] = useState<any[]>([]);
    const [isCartOpen, setIsCartOpen] = useState(false);

    useEffect(() => {
        fetchMenu();
        fetchActiveOrders();

        // Suscripción a mis pedidos
        const channel = supabase
            .channel(`table-${tableId}-orders`)
            .on(
                'postgres_changes',
                { event: '*', schema: 'public', table: 'orders', filter: `table_number=eq.${tableId}` },
                () => {
                    fetchActiveOrders();
                }
            )
            .subscribe();

        return () => { supabase.removeChannel(channel); };
    }, []);

    const fetchActiveOrders = async () => {
        const { data } = await supabase
            .from('orders')
            .select('*')
            .eq('table_number', parseInt(tableId))
            .neq('status', 'served')
            .order('created_at', { ascending: false });
        if (data) setActiveOrders(data);
    };

    const fetchMenu = async () => {
        const { data } = await supabase
            .from('products')
            .select('*')
            .eq('is_available', true);
        if (data) setMenu(data);

        // Obtener total de pedidos activos
        const { count } = await supabase
            .from('orders')
            .select('*', { count: 'exact', head: true })
            .in('status', ['pending', 'cooking']);

        setTotalOrders(count || 0);
        setLoading(false);
    };

    const addToCart = (product: Product) => {
        setCart(prev => {
            const existing = prev.find(item => item.product.id === product.id);
            if (existing) {
                return prev.map(item =>
                    item.product.id === product.id ? { ...item, qty: item.qty + 1 } : item
                );
            }
            return [...prev, { product, qty: 1 }];
        });
    };

    const removeFromCart = (productId: string) => {
        setCart(prev => prev.filter(item => item.product.id !== productId));
    };

    const updateQty = (productId: string, delta: number) => {
        setCart(prev => {
            return prev.map(item => {
                if (item.product.id === productId) {
                    const newQty = Math.max(1, item.qty + delta);
                    return { ...item, qty: newQty };
                }
                return item;
            });
        });
    };

    const handleCheckout = async () => {
        if (cart.length === 0) return;
        try {
            // Aplanar el carrito para la base de datos (se espera una lista de ítems)
            const flattenedItems = cart.flatMap(item =>
                Array(item.qty).fill(null).map(() => ({
                    ...item.product,
                    qty: 1 // La API espera ítems individuales o qty por ítem, lo mantenemos como objetos de producto
                }))
            );

            const totalToPay = cart.reduce((acc, item) => acc + (Number(item.product.price) * item.qty), 0);

            const { data: order, error: orderError } = await supabase
                .from('orders')
                .insert([{
                    table_number: parseInt(tableId),
                    items: flattenedItems,
                    total_amount: totalToPay,
                    status: 'pending'
                }])
                .select()
                .single();

            if (orderError) throw orderError;

            setCart([]);
            setIsCartOpen(false);
            alert("✅ ¡Pedido enviado a cocina!");
        } catch (error: any) {
            console.error("Error en checkout:", error);
            alert(`Error al procesar el pedido: ${error.message || "Avisa al personal"}`);
        }
    };

    const total = cart.reduce((acc, item) => acc + (Number(item.product.price) * item.qty), 0);
    const cartCount = cart.reduce((acc, item) => acc + item.qty, 0);

    if (loading) return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 gap-4">
            <Loader2 className="w-10 h-10 animate-spin text-orange-500" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Cargando Carta El Remei...</p>
        </div>
    );

    return (
        <div className="flex flex-col md:flex-row min-h-screen bg-[#FDFCFB] font-sans text-gray-900">
            {/* Modal de Carrito / Revisión */}
            <AnimatePresence>
                {isCartOpen && (
                    <>
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={() => setIsCartOpen(false)}
                            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100]"
                        />
                        <motion.div
                            initial={{ y: '100%' }}
                            animate={{ y: 0 }}
                            exit={{ y: '100%' }}
                            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                            className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto bg-white rounded-t-[3rem] z-[101] overflow-hidden flex flex-col max-h-[90vh] shadow-2xl"
                        >
                            <div className="p-8 pb-4 flex justify-between items-center border-b border-gray-50">
                                <div>
                                    <h2 className="text-2xl font-black italic">Mi Pedido</h2>
                                    <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest">Revisa antes de marchar</p>
                                </div>
                                <button onClick={() => setIsCartOpen(false)} className="bg-gray-100 p-3 rounded-2xl hover:bg-gray-200 transition-all">
                                    <X className="w-6 h-6 text-gray-400" />
                                </button>
                            </div>

                            <div className="flex-1 overflow-y-auto p-8 space-y-4 no-scrollbar">
                                {cart.map((item) => (
                                    <div key={item.product.id} className="bg-gray-50 p-4 rounded-3xl border border-gray-100 flex items-center gap-4">
                                        <div className="w-16 h-16 bg-gray-200 rounded-2xl flex-shrink-0 overflow-hidden">
                                            {item.product.image_url && <img src={item.product.image_url} className="w-full h-full object-cover" />}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <h3 className="font-black text-sm truncate uppercase">{item.product.name}</h3>
                                            <p className="text-orange-600 font-black text-xs">{(Number(item.product.price) * item.qty).toFixed(2)}€</p>
                                        </div>
                                        <div className="flex items-center gap-2 bg-white p-1 rounded-2xl border border-gray-100 shadow-sm">
                                            <button onClick={() => updateQty(item.product.id, -1)} className="w-8 h-8 flex items-center justify-center hover:text-orange-500 transition-colors">
                                                <Minus className="w-4 h-4" />
                                            </button>
                                            <span className="w-4 text-center text-sm font-black italic">{item.qty}</span>
                                            <button onClick={() => updateQty(item.product.id, 1)} className="w-8 h-8 flex items-center justify-center hover:text-orange-500 transition-colors">
                                                <Plus className="w-4 h-4" />
                                            </button>
                                        </div>
                                        <button onClick={() => removeFromCart(item.product.id)} className="bg-red-50 p-3 rounded-2xl text-red-500 hover:bg-red-100 transition-all">
                                            <Trash2 className="w-5 h-5" />
                                        </button>
                                    </div>
                                ))}
                                {cart.length === 0 && (
                                    <div className="py-20 flex flex-col items-center opacity-20">
                                        <ShoppingCart className="w-16 h-16 mb-4" />
                                        <p className="font-black uppercase italic">¡Carrito vacío!</p>
                                    </div>
                                )}
                            </div>

                            <div className="p-8 bg-white border-t border-gray-50">
                                <div className="flex justify-between items-center mb-6">
                                    <span className="text-gray-400 font-black uppercase text-xs">Total del pedido</span>
                                    <span className="text-3xl font-black text-orange-600 italic">
                                        {total.toFixed(2)}€
                                    </span>
                                </div>
                                <button
                                    onClick={handleCheckout}
                                    disabled={cart.length === 0}
                                    className="w-full bg-orange-600 hover:bg-orange-700 disabled:bg-gray-200 disabled:text-gray-400 text-white py-6 rounded-3xl font-black text-xl italic transition-all active:scale-95 shadow-xl shadow-orange-100 flex items-center justify-center gap-4"
                                >
                                    ¡ENVIAR A COCINA!
                                    <Utensils className="w-6 h-6" />
                                </button>
                            </div>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>

            {/* Mobile Header */}
            <header className="md:hidden bg-white px-6 py-4 flex flex-col sticky top-0 z-20 shadow-sm border-b border-gray-100 italic">
                {totalOrders > 10 && (
                    <div className="mb-3 bg-orange-50 border border-orange-100 p-2 rounded-lg flex items-center gap-2">
                        <div className="w-2 h-2 bg-orange-500 rounded-full animate-ping"></div>
                        <p className="text-[9px] font-black text-orange-700 uppercase">
                            Cocina Saturada: Espera ~25 min
                        </p>
                    </div>
                )}
                <div className="flex justify-between items-center w-full">
                    <Link href="/" className="p-2 -ml-2"><ArrowLeft className="w-6 h-6" /></Link>
                    <div className="flex flex-col items-center">
                        <h1 className="text-xl font-black text-orange-600">EL REMEI</h1>
                        <p className="text-[10px] uppercase font-black text-gray-400">MESA {tableId}</p>
                    </div>
                    <button onClick={() => setIsCartOpen(true)} className="relative">
                        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                            <ShoppingCart className="w-5 h-5 text-gray-700" />
                            {cartCount > 0 && (
                                <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">
                                    {cartCount}
                                </span>
                            )}
                        </div>
                    </button>
                </div>
            </header>

            {/* Sidebar Navigation */}
            <aside className="hidden md:flex w-72 bg-white flex-col sticky top-0 h-screen border-r border-gray-100 p-8">
                {totalOrders > 10 && (
                    <div className="mb-6 bg-orange-50 border border-orange-100 p-3 rounded-xl flex items-center gap-3 animate-pulse">
                        <div className="bg-orange-500 p-1.5 rounded-lg flex-shrink-0">
                            <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <p className="text-[10px] font-black text-orange-700 uppercase leading-tight">
                            Cocina Saturada: +10 en cola
                        </p>
                    </div>
                )}
                <div className="mb-12 flex items-center gap-3">
                    <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center text-white">
                        <Utensils className="w-6 h-6" />
                    </div>
                    <div>
                        <h1 className="text-xl font-black tracking-tighter">EL REMEI</h1>
                        <p className="text-[10px] text-gray-400 font-bold tracking-widest uppercase">Restaurante Polígono</p>
                    </div>
                </div>

                <div className="space-y-4">
                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-6">Categorías</p>
                    {CATEGORIES.map((cat) => (
                        <button
                            key={cat.id}
                            onClick={() => setActiveCategory(cat.id)}
                            className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all duration-300 ${activeCategory === cat.id ? 'bg-orange-50 text-orange-600 shadow-sm shadow-orange-100' : 'text-gray-500 hover:bg-gray-50'}`}
                        >
                            <span className="text-xl">{cat.icon}</span>
                            {cat.name}
                        </button>
                    ))}
                </div>

                <div className="mt-8">
                    <p className="text-[10px] text-gray-400 font-bold uppercase mb-4 tracking-widest">Estado de mi Mesa</p>
                    <div className="space-y-2 max-h-48 overflow-y-auto no-scrollbar">
                        {activeOrders.length > 0 ? (
                            activeOrders.flatMap(o => o.items.map((item: any, i: number) => {
                                const isDrink = item.category?.toLowerCase() === 'bebida';
                                const isReady = isDrink ? o.drinks_served : item.is_served;

                                return (
                                    <div key={i} className={`flex items-center justify-between text-[11px] p-2 rounded-lg border ${isReady ? 'bg-emerald-50/50 border-emerald-100' : 'bg-gray-50 border-gray-100'}`}>
                                        <span className={`font-bold transition-all ${isReady ? 'text-emerald-700 opacity-60' : 'text-gray-600'}`}>{item.name}</span>
                                        {isReady ? (
                                            <span className="text-emerald-600 font-black flex items-center gap-1">
                                                <CheckCircle className="w-3 h-3" />
                                                SERVIDO
                                            </span>
                                        ) : (
                                            <span className="text-orange-500 font-black animate-pulse">
                                                {isDrink ? 'BARRA' : 'COCINANDO'}
                                            </span>
                                        )}
                                    </div>
                                );
                            }))
                        ) : (
                            <p className="text-[10px] text-gray-400 italic">No hay platos marchando</p>
                        )}
                    </div>
                </div>

                <div className="mt-auto p-6 bg-gray-50 rounded-3xl border border-gray-100">
                    <p className="text-[10px] text-gray-400 font-bold uppercase mb-2">Ubicación</p>
                    <p className="text-sm font-bold text-gray-700">Mesa {tableId}</p>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 flex flex-col">
                {/* Top Search Bar (Desktop) */}
                <div className="hidden md:flex px-12 py-8 justify-between items-center">
                    <div className="relative w-96">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300" />
                        <input
                            type="text"
                            placeholder="Buscar plato..."
                            className="w-full pl-12 pr-4 py-3 bg-gray-100/50 border-none rounded-2xl focus:ring-2 focus:ring-orange-500/20 text-sm font-medium"
                        />
                    </div>
                </div>

                {/* Mobile Category Scroll */}
                <div className="md:hidden flex overflow-x-auto px-4 py-4 gap-2 no-scrollbar bg-white shadow-sm sticky top-[72px] z-10 transition-all">
                    {CATEGORIES.map((cat) => (
                        <button
                            key={cat.id}
                            onClick={() => setActiveCategory(cat.id)}
                            className={`whitespace-nowrap px-6 py-3 rounded-xl font-bold text-sm transition-all ${activeCategory === cat.id ? 'bg-orange-500 text-white shadow-lg shadow-orange-200' : 'bg-gray-100 text-gray-500'}`}
                        >
                            {cat.icon} {cat.name}
                        </button>
                    ))}
                </div>

                {/* Mobile Active Orders Section */}
                {activeOrders.length > 0 && (
                    <div className="md:hidden px-4 mt-4">
                        <div className="bg-zinc-900 rounded-[2rem] p-5 shadow-xl border border-white/5">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-white font-black italic uppercase text-xs tracking-widest flex items-center gap-2">
                                    <div className="w-1.5 h-4 bg-orange-500 rounded-full"></div>
                                    Mis Pedidos Actuales
                                </h3>
                                <span className="text-[10px] bg-orange-500/20 text-orange-400 px-2 py-0.5 rounded-full font-black uppercase">En curso</span>
                            </div>
                            <div className="space-y-3 max-h-48 overflow-y-auto no-scrollbar">
                                {activeOrders.flatMap((o, oi) => o.items.map((item: any, ii: number) => {
                                    const isDrink = item.category?.toLowerCase() === 'bebida';
                                    const isReady = isDrink ? o.drinks_served : item.is_served;

                                    return (
                                        <div key={`${oi}-${ii}`} className={`flex justify-between items-center p-3 rounded-2xl border ${isReady ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-white/5 border-white/5'}`}>
                                            <div className="flex items-center gap-3">
                                                <div className={`w-2 h-2 rounded-full ${isReady ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-orange-500 animate-pulse'}`}></div>
                                                <span className={`text-[11px] font-bold ${isReady ? 'text-emerald-400' : 'text-gray-300'}`}>{item.name}</span>
                                            </div>
                                            <span className={`text-[9px] font-black uppercase tracking-tighter ${isReady ? 'text-emerald-500' : 'text-orange-500/60'}`}>
                                                {isReady ? 'Servido' : (isDrink ? 'Barra' : 'Cocina')}
                                            </span>
                                        </div>
                                    );
                                }))}
                            </div>
                        </div>
                    </div>
                )}

                {/* Grid of Dishes */}
                <div className="flex-1 px-4 md:px-12 py-6 pb-40">
                    <div className="flex justify-between items-end mb-8">
                        <h2 className="text-3xl md:text-4xl font-black text-gray-900 capitalize">
                            {CATEGORIES.find(c => c.id === activeCategory)?.name}
                        </h2>
                        <p className="text-sm text-gray-400 font-bold">
                            {menu.filter(p => p.category === activeCategory).length} especialidades
                        </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {menu.filter(p => p.category === activeCategory).length > 0 ? (
                            menu.filter(p => p.category === activeCategory).map(product => (
                                <div
                                    key={product.id}
                                    className="group bg-white rounded-[2.5rem] p-4 shadow-sm hover:shadow-2xl hover:shadow-orange-100 transition-all duration-500 border border-gray-100/50 flex flex-col cursor-pointer active:scale-95"
                                    onClick={() => addToCart(product)}
                                >
                                    <div className="aspect-[4/3] w-full bg-gray-100 rounded-[2rem] mb-6 overflow-hidden relative">
                                        {product.image_url ? (
                                            <img src={product.image_url} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                                        ) : (
                                            <div className="w-full h-full flex items-center justify-center opacity-10">
                                                <Utensils className="w-20 h-20" />
                                            </div>
                                        )}
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                                        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md w-12 h-12 rounded-2xl flex items-center justify-center text-orange-500 shadow-xl group-hover:bg-orange-500 group-hover:text-white transition-all duration-300">
                                            <Plus className="w-6 h-6" />
                                        </div>
                                    </div>
                                    <div className="px-2 pb-2">
                                        <div className="flex justify-between items-start mb-2 gap-2">
                                            <h3 className="font-black text-lg text-gray-800 leading-tight">{product.name}</h3>
                                            <span className="text-orange-600 font-black text-lg">{Number(product.price).toFixed(2)}€</span>
                                        </div>
                                        <p className="text-xs text-gray-400 font-medium leading-relaxed">{product.description || "Deliciosa especialidad de El Remei preparada con ingredientes frescos del día."}</p>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="col-span-full py-20 flex flex-col items-center opacity-20">
                                <Utensils className="w-20 h-20 mb-4" />
                                <p className="text-2xl font-black uppercase italic text-center px-4">Esta categoría está vacía por ahora</p>
                            </div>
                        )}
                    </div>
                </div>
            </main>

            {/* Floating Action Button / Cart */}
            {cart.length > 0 && (
                <div id="checkout-action" className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[calc(100%-3rem)] max-w-lg z-30">
                    <button
                        onClick={() => setIsCartOpen(true)}
                        className="w-full bg-orange-600 hover:bg-orange-700 text-white p-2 rounded-[2rem] shadow-2xl flex items-center justify-between group transition-all transform hover:scale-[1.02] active:scale-95 border-b-4 border-orange-800"
                    >
                        <div className="flex items-center gap-4 ml-4">
                            <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                <ShoppingCart className="w-7 h-7" />
                            </div>
                            <div className="text-left">
                                <p className="text-[10px] font-black opacity-80 uppercase tracking-widest">Revisar Pedido</p>
                                <p className="text-xl font-black italic">({cartCount} items)</p>
                            </div>
                        </div>
                        <div className="bg-orange-500 px-8 py-5 rounded-[1.8rem] text-2xl font-black shadow-lg">
                            {total.toFixed(2)}€
                        </div>
                    </button>
                    <button onClick={() => setCart([])} className="absolute -top-3 -right-3 w-8 h-8 bg-zinc-900 text-white rounded-full flex items-center justify-center shadow-xl border border-white/10 text-xs font-black">X</button>
                </div>
            )}
        </div>
    );
}
